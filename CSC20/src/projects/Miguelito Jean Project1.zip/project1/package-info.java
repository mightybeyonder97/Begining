/** Name: Miguelito Jean
 * Class : CSC205
 */
/**
 * @author migue
 *
 */
package projects.project1;