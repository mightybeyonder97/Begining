/** Name: Miguelito Jean
 * Class : CSC205
 */
package projects.project4.csc205;



public class Recursion {
	
	
    
    public static int fib (int n)
    {
    	int fibNum;
    	if (n <= 0) {
    		fibNum = 0;
    	}
    	else if(n <= 2) {
    		fibNum = 1;
    	}
    	else {
    	
        fibNum = (fib(n -1) + fib(n-2));
    	}
    	return fibNum;
    	
    }
     
    public static int power (int x, int y)
    {
    	if (y <= 0) {
    		return 1;
    	}
    	else {
        return (x * power(x, y-1));
    	}
    }
     
    public static int ackermann(int m, int n)
    {
    	if( m  == 0) {
    		return n + 1;
    	}
    	else if ( m > 0 & n == 0) {
    		return (ackermann(m-1, 1));
    	}
    	else  {
        return (ackermann(m-1,ackermann(m, n -1)));
    	}
    }

   /* public static void triangle(int height)
    {
    }

    
    public static int balance (int x, int y)
    {
        return 0;
    }
     
	public static double pi_approximation(int n)
	{
        return 0;
	}

	public static boolean isPalindrome(String s)
	{
		return false;
	}
		
	public static boolean monotonicallyIncreasing(Integer[] a)
	{
		return false;
	} */
	
}