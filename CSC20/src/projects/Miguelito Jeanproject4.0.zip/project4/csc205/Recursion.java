/** Name: Miguelito Jean
 * Class : CSC205
 */
package projects.project4.csc205;



public class Recursion {
	
	
    
    public static int fib (int n)
    {
    	int fibNum;
    	if (n <= 0) {
    		fibNum = 0;
    	}
    	else if(n <= 2) {
    		fibNum = 1;
    	}
    	else {
    	
        fibNum = (fib(n -1) + fib(n-2));
    	}
    	return fibNum;
    	
    }
     
    public static int power (int x, int y)
    {
    	if (y <= 0) {
    		return 1;
    	}
    	else {
        return (x * power(x, y-1));
    	}
    }
     
    public static int ackermann(int m, int n)
    {
    	if( m  == 0) {
    		return n + 1;
    	}
    	else if ( m > 0 & n == 0) {
    		return (ackermann(m-1, 1));
    	}
    	else  {
        return (ackermann(m-1,ackermann(m, n -1)));
    	}
    }

   
    
    public static int balance (int x, int y)
    {	
    	int mean;
    	
    	
    	if (x + 1 == y  && y-1 == x) {
    	
    		return x;
    	}
    	
    	else if(y + 1 == x && x - 1 == y) {
    		
    		return y;
    	}
    	 if (y<=0) {
     		return 0;
     	}
     	
    	
    	if (x < y ) {
    		y-= 1;
    		
    		mean = (1 +  balance(x ,y-1));
    		return mean;
    	}
    	
    	else  {
    	x -= 1;
    	
    	mean =	( 1 +  balance(x-1,y) );
    	
    	return  mean;
    	}
    	
    	}

	public static double pi_approximation(int n)
	{
		
		if (n <= 0) {
			return 0;
		}
		
		else {
			return ((Math.pow(-1, n+1) * 4) / ((2*n)-1)) + pi_approximation(n-1);
		}
			
	}

	public static boolean isPalindrome(String s)
	{ 
		
		
		return false;
	}
		
	public static boolean monotonicallyIncreasing(Integer[] a)
	{ 
			return false;
		}
	
	}


