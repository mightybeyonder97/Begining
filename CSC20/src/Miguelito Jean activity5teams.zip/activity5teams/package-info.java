/** Name: Miguelito Jean
 * Class : CSC205
 */
/**
 * @author migue
 *
 */
package activity5teams;