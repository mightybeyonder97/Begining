/** Name: Miguelito Jean
 * Class : CSC205
 */
package activities.activity3;


public interface Priority {
	
	
	
	void setPriority(int p);
	int getPriority();

}
