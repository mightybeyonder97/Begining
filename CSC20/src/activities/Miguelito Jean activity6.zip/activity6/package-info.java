/** Name: Miguelito Jean
 * Class : CSC205
 */
/**
 * @author migue
 *
 */
package activities.activity6;