/**Miguelito Jean
 * 
 */
package activities.activity1;

/**
 * @author Miguelito
 *
 */
public class Activity1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Card  playerCard =new Card();
     
     
    
    System.out.println(playerCard.toString());
    playerCard.namesOfCards();
     
     
     
	

}
}
