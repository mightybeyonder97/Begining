/** Name: Miguelito Jean
 * Class : CSC205
 */
package project3.characters;


public class GameDriver {

	
	public static void main(String[] args) {
		
		
		Fremen f  = new Fremen("Muad' Dib" , 15 ,20, 100);
		Sardukar s = new Sardukar("Shadam", 15,15,80);
		BeneGeserit b = new BeneGeserit("Miles Teg", 30, 100, 150);
		
		System.out.println("Starting game");
		System.out.println(" \nRound 1:      " + f + "    vs    " + s);
		System.out.println("   \nLet the fight begin");
		s.hit(f.attact());
		s.isAlive();
		
		System.out.println(" \nRound 2:      " + f + "        " + s);
        f.hit(s.attact());
        s.hit(f.attact());
        
        System.out.println(" \nRound 3:      " + f + "        " + s);
        s.hit(f.attact());
        if (s.health == 0) {
        	s.isAlive();
        }
        
        System.out.println("   \nA new challenger has entered the arena     " + b);
        System.out.println("   To be continued.........");
	}

}
